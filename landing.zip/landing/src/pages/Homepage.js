// src/pages/Homepage.js
import React from 'react';
import ImageCarousel from '../Components/ImageCarousel';
import CustomSlider from '../Components/CustomSlider';
import './Homepage.css';


const HomePage = () => {
  return (
    <div>
    <div className="image-carousel-container">
      <ImageCarousel />
    </div>
    <div className="custom-slider-container">
      <CustomSlider/>
    </div>
  </div>
    
  );
};

export default HomePage;
