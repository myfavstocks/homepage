import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './CustomSlider.css';

// Import the images
import chessFest from '../Images/chess_fest.jpg';
import chessProfile from '../Images/chess_profile.jpg';
import chessTournament from '../Images/chess_tournament.jpg';
import dalCampus from '../Images/dal_campus.jpg';
import dalCounter from '../Images/dal_counter.jpg';

const slidesData = [
  {
    image: chessFest,
    title: 'LOOKING TO JOIN US?',
    subtitle: 'Sign Up through the USC Store',
  },
  {
    image: chessProfile,
    title: 'WEEKLY MEETINGS',
    subtitle: 'Monday and Thursday 5:30 PM to 8:30 PM',
  },
  {
    image: chessTournament,
    title: 'ONLINE CLUBS',
    subtitle: 'Learn more here!',
  },
  // Add additional slides as needed
];

function CustomSlider() {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <Slider {...settings}>
      {slidesData.map((slide, index) => (
        <div key={index} className="slide">
          <div className="image-wrapper">
            <img className="image" src={slide.image} alt={slide.title} />
            <div className="text-overlay">
              <h3>{slide.title}</h3>
              <p>{slide.subtitle}</p>
            </div>
          </div>
        </div>
      ))}
    </Slider>
  );
}

function SampleNextArrow(props) {
  const { className, onClick } = props;
  return (
    <div className={`${className} custom-arrow next-arrow`} onClick={onClick} />
  );
}

function SamplePrevArrow(props) {
  const { className, onClick } = props;
  return (
    <div className={`${className} custom-arrow prev-arrow`} onClick={onClick} />
  );
}

export default CustomSlider;

