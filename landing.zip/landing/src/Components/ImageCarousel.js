import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './ImageCarousel.css';

const ImageCarousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <div className="image-carousel">
      <Slider {...settings}>
        {[1, 2, 3, 4, 5].map(num => (
          <div key={num} className="slide">
            <h3>{num}</h3>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default ImageCarousel;
